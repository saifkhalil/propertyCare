from django.contrib import admin
from .models import Property, Floor, Room, RoomType, Task, MaintenanceRequest, Team


@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('name', 'location', 'size', 'owner', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(Floor)
class FloorAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('name', 'property', 'number_of_rooms', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('name', 'floor', 'room_type', 'size', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(RoomType)
class RoomTypeAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('type_name', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('title', 'description', 'assigned_to', 'due_date', 'status', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(MaintenanceRequest)
class MaintenanceRequestAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('property', 'issue_description', 'request_date', 'status', 'assigned_team', 'created_at', 'created_by', 'modified_at', 'modified_by')


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    readonly_fields = ['created_at', 'created_by', 'modified_at', 'modified_by']
    list_display = ('name', 'created_at', 'created_by', 'modified_at', 'modified_by')
    filter_horizontal = ('members',)