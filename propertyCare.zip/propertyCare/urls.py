from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PropertyViewSet, FloorViewSet, RoomViewSet, RoomTypeViewSet, TaskViewSet, MaintenanceRequestViewSet, \
    TeamViewSet, StatusViewSet

router = DefaultRouter()
router.register(r'properties', PropertyViewSet)
router.register(r'floors', FloorViewSet)
router.register(r'rooms', RoomViewSet)
router.register(r'room-types', RoomTypeViewSet)
router.register(r'status', StatusViewSet)
router.register(r'tasks', TaskViewSet)
router.register(r'maintenance-requests', MaintenanceRequestViewSet)
router.register(r'teams', TeamViewSet)

urlpatterns = [
    path('', include(router.urls)),
]