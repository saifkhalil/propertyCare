from rest_framework import serializers
from .models import Property, Floor, Room, RoomType, Team, MaintenanceRequest, Task, Status


class RoomTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomType
        fields = '__all__'


class RoomSerializer(serializers.ModelSerializer):
    room_type = RoomTypeSerializer(read_only=True)
    room_type_id = serializers.PrimaryKeyRelatedField(queryset=RoomType.objects.all(), write_only=True, source='room_type')

    class Meta:
        model = Room
        fields = ['id', 'name', 'size', 'room_type', 'room_type_id', 'created_at', 'created_by', 'modified_at', 'modified_by']


class FloorSerializer(serializers.ModelSerializer):
    rooms = RoomSerializer(many=True, read_only=True)

    class Meta:
        model = Floor
        fields = '__all__'


class PropertySerializer(serializers.ModelSerializer):
    floors = FloorSerializer(many=True, read_only=True)

    class Meta:
        model = Property
        fields = '__all__'

class StatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = Status
        fields = '__all__'

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'


class TeamSerializer(serializers.ModelSerializer):
    class Meta:
        model = Team
        fields = '__all__'


class MaintenanceRequestSerializer(serializers.ModelSerializer):
    assigned_team = TeamSerializer(read_only=True)
    assigned_team_id = serializers.PrimaryKeyRelatedField(queryset=Team.objects.all(), write_only=True, source='assigned_team')

    class Meta:
        model = MaintenanceRequest
        fields = ['id', 'property', 'issue_description', 'request_date', 'status', 'assigned_team', 'assigned_team_id']