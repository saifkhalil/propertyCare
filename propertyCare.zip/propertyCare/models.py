from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, related_name="%(class)s_created_by", on_delete=models.SET_NULL, null=True)
    modified_at = models.DateTimeField(auto_now=True)
    modified_by = models.ForeignKey(User, related_name="%(class)s_modified_by", on_delete=models.SET_NULL, null=True)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if not self.pk:
            self.created_at = timezone.now()
        else:
            self.modified_at = timezone.now()



class Property(BaseModel):
    name = models.CharField(max_length=255)
    location = models.TextField()
    size = models.FloatField()
    owner = models.ForeignKey(User, related_name="properties", on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.name


class Floor(BaseModel):
    property = models.ForeignKey(Property, related_name="floors", on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    number_of_rooms = models.IntegerField()

    def __str__(self):
        return f"{self.name} - {self.property.name}"


class RoomType(BaseModel):
    type_name = models.CharField(max_length=100)

    def __str__(self):
        return self.type_name


class Room(BaseModel):
    floor = models.ForeignKey(Floor, related_name="rooms", on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    room_type = models.ForeignKey(RoomType, related_name="rooms", on_delete=models.CASCADE)
    size = models.FloatField()

    def __str__(self):
        return f"{self.name} - {self.floor.name} ({self.room_type.type_name})"


class Status(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Task(BaseModel):
    title = models.CharField(max_length=255)
    description = models.TextField()
    assigned_to = models.ForeignKey(User, related_name="tasks", on_delete=models.SET_NULL, null=True)
    due_date = models.DateField()
    status = models.ForeignKey(Status, related_name="%(class)s_status", on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class Team(BaseModel):
    name = models.CharField(max_length=255)
    members = models.ManyToManyField(User, related_name="teams")

    def __str__(self):
        return self.name

class MaintenanceRequest(BaseModel):
    property = models.ForeignKey(Property, related_name="maintenance_requests", on_delete=models.CASCADE)
    issue_description = models.TextField()
    request_date = models.DateField(auto_now_add=True)
    status = models.ForeignKey(Status, related_name="%(class)s_status", on_delete=models.CASCADE)
    assigned_team = models.ForeignKey(Team, related_name="maintenance_requests", on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.property.name} - {self.status}"